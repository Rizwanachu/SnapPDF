// PDF Tools App JavaScript
class PDFToolsApp {
    constructor() {
        this.uploadedFiles = new Map();
        this.currentJobType = null;
        this.processingJobs = new Map();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeDragAndDrop();
    }

    setupEventListeners() {
        // File input change listeners
        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', (e) => {
                const jobType = this.getJobTypeFromInput(e.target);
                this.handleFileSelection(e.target.files, jobType);
            });
        });

        // Convert type change listener
        document.querySelectorAll('input[name="convertType"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.updateConvertType(e.target.value);
            });
        });
    }

    initializeDragAndDrop() {
        document.querySelectorAll('.upload-zone').forEach(zone => {
            const jobType = this.getJobTypeFromZone(zone);
            
            zone.addEventListener('dragover', (e) => {
                e.preventDefault();
                zone.closest('.file-upload-area').classList.add('drag-over');
            });

            zone.addEventListener('dragleave', (e) => {
                e.preventDefault();
                zone.closest('.file-upload-area').classList.remove('drag-over');
            });

            zone.addEventListener('drop', (e) => {
                e.preventDefault();
                zone.closest('.file-upload-area').classList.remove('drag-over');
                this.handleFileSelection(e.dataTransfer.files, jobType);
            });

            zone.addEventListener('click', () => {
                const fileInput = document.querySelector(`#file-input-${jobType}`);
                if (fileInput) {
                    fileInput.click();
                }
            });
        });
    }

    getJobTypeFromInput(input) {
        return input.id.replace('file-input-', '');
    }

    getJobTypeFromZone(zone) {
        return zone.id.replace('upload-zone-', '');
    }

    handleFileSelection(files, jobType) {
        const fileArray = Array.from(files);
        
        // Validate files
        const invalidFiles = fileArray.filter(file => !file.name.toLowerCase().endsWith('.pdf'));
        if (invalidFiles.length > 0) {
            this.showError(`Please select only PDF files. ${invalidFiles.length} invalid file(s) detected.`);
            return;
        }

        // Check file size limits
        const maxFileSize = 10 * 1024 * 1024; // 10MB for free users
        const oversizedFiles = fileArray.filter(file => file.size > maxFileSize);
        if (oversizedFiles.length > 0) {
            this.showError(`Some files exceed the 10MB limit: ${oversizedFiles.map(f => f.name).join(', ')}`);
            return;
        }

        // Check batch limit
        const maxBatchSize = 5; // 5 files for free users
        if (fileArray.length > maxBatchSize) {
            this.showError(`Maximum ${maxBatchSize} files allowed per batch for free users.`);
            return;
        }

        this.uploadFiles(fileArray, jobType);
    }

    async uploadFiles(files, jobType) {
        const formData = new FormData();
        files.forEach(file => {
            formData.append('files', file);
        });

        let retryCount = 0;
        const maxRetries = 2;

        while (retryCount <= maxRetries) {
            try {
                this.showLoading(`Uploading ${files.length} file(s)...${retryCount > 0 ? ` (Attempt ${retryCount + 1})` : ''}`);
                
                const response = await fetch('/upload', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (!response.ok) {
                    throw new Error(`Server error: ${response.status}`);
                }

                const result = await response.json();
                
                if (result.error) {
                    throw new Error(result.error);
                }

                this.displayUploadedFiles(result.files, jobType);
                this.showSuccess(`Successfully uploaded ${result.files.length} file(s)`);
                
                // Store uploaded files for this job type
                this.uploadedFiles.set(jobType, result.files);
                
                // Show processing controls
                this.showProcessingControls(jobType);
                
                this.hideLoading();
                return; // Success - exit retry loop
                
            } catch (error) {
                retryCount++;
                console.error(`Upload attempt ${retryCount} failed:`, error);
                
                if (retryCount > maxRetries) {
                    this.showError(`Upload failed after ${maxRetries + 1} attempts: ${error.message}`);
                    this.hideLoading();
                    return;
                } else if (retryCount <= maxRetries) {
                    // Wait before retry
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }
        }
    }

    displayUploadedFiles(files, jobType) {
        const fileList = document.getElementById(`file-list-${jobType}`);
        fileList.innerHTML = '';
        fileList.classList.add('has-files');

        files.forEach(file => {
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item fade-in';
            fileItem.innerHTML = `
                <div class="file-info">
                    <i class="fas fa-file-pdf"></i>
                    <div class="file-details">
                        <h6>${file.original_filename}</h6>
                        <small>${file.formatted_size}</small>
                        <div class="mt-1">
                            <button class="btn btn-sm btn-outline-info me-1" onclick="pdfApp.previewFile('${file.id}')" title="Preview">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="pdfApp.showFileInfo('${file.id}')" title="File Info">
                                <i class="fas fa-info-circle"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="file-actions">
                    <button class="btn btn-sm btn-outline-danger" onclick="pdfApp.removeFile('${jobType}', '${file.id}')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            fileList.appendChild(fileItem);
        });
    }

    showProcessingControls(jobType) {
        const controls = document.getElementById(`controls-${jobType}`);
        controls.classList.remove('d-none');
        controls.classList.add('d-flex');
    }

    hideProcessingControls(jobType) {
        const controls = document.getElementById(`controls-${jobType}`);
        controls.classList.add('d-none');
        controls.classList.remove('d-flex');
    }

    removeFile(jobType, fileId) {
        const files = this.uploadedFiles.get(jobType);
        if (!files) return;

        const updatedFiles = files.filter(f => f.id !== fileId);
        this.uploadedFiles.set(jobType, updatedFiles);

        if (updatedFiles.length === 0) {
            this.clearFiles(jobType);
        } else {
            this.displayUploadedFiles(updatedFiles, jobType);
        }
    }

    clearFiles(jobType) {
        const fileList = document.getElementById(`file-list-${jobType}`);
        fileList.innerHTML = '';
        fileList.classList.remove('has-files');
        
        this.uploadedFiles.delete(jobType);
        this.hideProcessingControls(jobType);
    }

    async startProcessing(jobType) {
        const files = this.uploadedFiles.get(jobType);
        if (!files || files.length === 0) {
            this.showError('No files selected for processing');
            return;
        }

        // Get actual job type for convert operations
        let actualJobType = jobType;
        if (jobType === 'convert') {
            const selectedType = document.querySelector('input[name="convertType"]:checked');
            actualJobType = selectedType ? selectedType.value : 'convert_word';
        }

        try {
            const response = await fetch('/process', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    job_type: actualJobType,
                    file_ids: files.map(f => f.id),
                    settings: this.getJobSettings(jobType)
                })
            });

            if (!response.ok) {
                throw new Error('Failed to start processing');
            }

            const result = await response.json();
            
            if (result.error) {
                throw new Error(result.error);
            }

            this.showSuccess(`Processing job created: ${result.job_id}`);
            this.addProcessingJob(result.job_id, actualJobType);
            
            // Clear the form
            this.clearFiles(jobType);
            
            // Show processing modal
            this.showProcessingModal(result.job_id);
            
        } catch (error) {
            this.showError(`Failed to start processing: ${error.message}`);
        }
    }

    getJobSettings(jobType) {
        const settings = {};
        
        if (jobType === 'convert') {
            const convertType = document.querySelector('input[name="convertType"]:checked');
            settings.convert_type = convertType ? convertType.value : 'convert_word';
        }
        
        if (jobType === 'compress') {
            const compressionQuality = document.querySelector('input[name="compressionQuality"]:checked');
            settings.compression_quality = compressionQuality ? compressionQuality.value : 'medium';
        }
        
        if (jobType === 'ocr') {
            const ocrLanguage = document.getElementById('ocrLanguage');
            const ocrOutputFormat = document.querySelector('input[name="ocrOutputFormat"]:checked');
            settings.ocr_language = ocrLanguage ? ocrLanguage.value : 'eng';
            settings.output_format = ocrOutputFormat ? ocrOutputFormat.value : 'txt';
        }
        
        return settings;
    }

    async previewFile(fileId) {
        try {
            // Show preview modal
            const previewModal = new bootstrap.Modal(document.getElementById('previewModal') || this.createPreviewModal());
            
            this.showLoading('Generating preview...');
            
            const img = document.getElementById('preview-image');
            img.src = `/preview/${fileId}`;
            img.onload = () => {
                this.hideLoading();
                previewModal.show();
            };
            img.onerror = () => {
                this.hideLoading();
                this.showError('Could not generate preview');
            };
            
        } catch (error) {
            this.hideLoading();
            this.showError(`Preview failed: ${error.message}`);
        }
    }

    async showFileInfo(fileId) {
        try {
            const response = await fetch(`/file-info/${fileId}`);
            if (!response.ok) {
                throw new Error('Failed to get file info');
            }
            
            const fileInfo = await response.json();
            
            if (fileInfo.error) {
                throw new Error(fileInfo.error);
            }
            
            // Show file info modal
            const infoModal = new bootstrap.Modal(document.getElementById('fileInfoModal') || this.createFileInfoModal());
            
            const infoContent = document.getElementById('file-info-content');
            infoContent.innerHTML = `
                <table class="table table-sm">
                    <tr><td><strong>Filename:</strong></td><td>${fileInfo.filename}</td></tr>
                    <tr><td><strong>File Size:</strong></td><td>${fileInfo.formatted_size}</td></tr>
                    <tr><td><strong>Pages:</strong></td><td>${fileInfo.pages}</td></tr>
                    <tr><td><strong>Upload Date:</strong></td><td>${new Date(fileInfo.upload_date).toLocaleString()}</td></tr>
                    <tr><td><strong>Encrypted:</strong></td><td>${fileInfo.encrypted ? 'Yes' : 'No'}</td></tr>
                </table>
            `;
            
            infoModal.show();
            
        } catch (error) {
            this.showError(`Failed to get file info: ${error.message}`);
        }
    }

    createPreviewModal() {
        const modalHTML = `
            <div class="modal fade" id="previewModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">PDF Preview</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body text-center">
                            <img id="preview-image" class="img-fluid" style="max-height: 500px;" alt="PDF Preview">
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        return document.getElementById('previewModal');
    }

    createFileInfoModal() {
        const modalHTML = `
            <div class="modal fade" id="fileInfoModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">File Information</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div id="file-info-content"></div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        return document.getElementById('fileInfoModal');
    }

    addProcessingJob(jobId, jobType) {
        this.processingJobs.set(jobId, {
            id: jobId,
            type: jobType,
            status: 'pending',
            progress: 0,
            created_at: new Date().toISOString()
        });
        
        this.updateJobsDisplay();
        this.startJobStatusUpdates(jobId);
    }

    async startJobStatusUpdates(jobId) {
        const updateInterval = setInterval(async () => {
            try {
                const response = await fetch(`/job/${jobId}/status`);
                if (!response.ok) {
                    clearInterval(updateInterval);
                    return;
                }

                const status = await response.json();
                
                if (status.error) {
                    clearInterval(updateInterval);
                    return;
                }

                this.updateJobStatus(jobId, status);
                
                // Stop polling if job is completed, failed, or cancelled
                if (['completed', 'failed', 'cancelled'].includes(status.status)) {
                    clearInterval(updateInterval);
                }
                
            } catch (error) {
                console.error('Error updating job status:', error);
            }
        }, 2000); // Poll every 2 seconds
    }

    updateJobStatus(jobId, status) {
        const job = this.processingJobs.get(jobId);
        if (!job) return;

        Object.assign(job, status);
        this.processingJobs.set(jobId, job);
        
        this.updateJobsDisplay();
        this.updateProcessingModal(jobId, status);
    }

    updateJobsDisplay() {
        const jobsContainer = document.getElementById('processing-jobs');
        if (!jobsContainer) return;

        if (this.processingJobs.size === 0) {
            jobsContainer.innerHTML = '<p class="text-muted">No active processing jobs.</p>';
            return;
        }

        jobsContainer.innerHTML = '';
        
        this.processingJobs.forEach((job, jobId) => {
            const jobElement = document.createElement('div');
            jobElement.className = 'job-item';
            jobElement.innerHTML = this.getJobHTML(job);
            jobsContainer.appendChild(jobElement);
        });
    }

    getJobHTML(job) {
        const statusClass = `status-${job.status}`;
        const progressPercent = job.progress || 0;
        
        return `
            <div class="job-header">
                <h6 class="job-title">${job.type.replace('_', ' ').toUpperCase()} Job</h6>
                <div class="job-status">
                    <span class="status-badge ${statusClass}">${job.status}</span>
                    ${job.status === 'completed' ? `
                        <a href="/download/${job.id}" class="btn btn-sm btn-success">
                            <i class="fas fa-download"></i>
                        </a>
                    ` : ''}
                    ${job.status === 'pending' ? `
                        <button class="btn btn-sm btn-outline-danger" onclick="pdfApp.cancelJob('${job.id}')">
                            <i class="fas fa-times"></i>
                        </button>
                    ` : ''}
                </div>
            </div>
            <div class="progress mb-2">
                <div class="progress-bar ${job.status === 'processing' ? 'progress-bar-striped progress-bar-animated' : ''}" 
                     role="progressbar" 
                     style="width: ${progressPercent}%"
                     aria-valuenow="${progressPercent}" 
                     aria-valuemin="0" 
                     aria-valuemax="100">
                </div>
            </div>
            <div class="d-flex justify-content-between">
                <small class="text-muted">
                    ${job.processed_files || 0} / ${job.total_files || 0} files processed
                </small>
                <small class="text-muted">
                    ${new Date(job.created_at).toLocaleString()}
                </small>
            </div>
            ${job.error_message ? `
                <div class="alert alert-danger mt-2 mb-0">
                    <small>${job.error_message}</small>
                </div>
            ` : ''}
        `;
    }

    showProcessingModal(jobId) {
        const modal = new bootstrap.Modal(document.getElementById('processingModal'));
        modal.show();
        
        const progressContainer = document.getElementById('processing-progress');
        progressContainer.innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <h5>Processing your files...</h5>
                <p class="text-muted">Job ID: ${jobId}</p>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                         role="progressbar" 
                         style="width: 0%">
                    </div>
                </div>
            </div>
        `;
    }

    updateProcessingModal(jobId, status) {
        const modal = document.getElementById('processingModal');
        if (!modal.classList.contains('show')) return;

        const progressContainer = document.getElementById('processing-progress');
        const progressBar = progressContainer.querySelector('.progress-bar');
        
        if (progressBar) {
            progressBar.style.width = `${status.progress || 0}%`;
            
            if (status.status === 'completed') {
                progressContainer.innerHTML = `
                    <div class="text-center">
                        <div class="text-success mb-3">
                            <i class="fas fa-check-circle" style="font-size: 3rem;"></i>
                        </div>
                        <h5>Processing Complete!</h5>
                        <p class="text-muted">Your files have been processed successfully.</p>
                        <a href="/download/${jobId}" class="btn btn-success">
                            <i class="fas fa-download me-2"></i>Download Results
                        </a>
                    </div>
                `;
            } else if (status.status === 'failed') {
                progressContainer.innerHTML = `
                    <div class="text-center">
                        <div class="text-danger mb-3">
                            <i class="fas fa-times-circle" style="font-size: 3rem;"></i>
                        </div>
                        <h5>Processing Failed</h5>
                        <p class="text-muted">${status.error_message || 'An error occurred during processing.'}</p>
                    </div>
                `;
            }
        }
    }

    async cancelJob(jobId) {
        if (!confirm('Are you sure you want to cancel this job?')) {
            return;
        }

        try {
            const response = await fetch(`/job/${jobId}/cancel`, {
                method: 'POST'
            });

            if (!response.ok) {
                throw new Error('Failed to cancel job');
            }

            const result = await response.json();
            
            if (result.error) {
                throw new Error(result.error);
            }

            this.showSuccess('Job cancelled successfully');
            this.processingJobs.delete(jobId);
            this.updateJobsDisplay();
            
        } catch (error) {
            this.showError(`Failed to cancel job: ${error.message}`);
        }
    }

    updateConvertType(type) {
        // Update UI to reflect selected conversion type
        const convertArea = document.querySelector('[data-job-type="convert"]');
        const title = convertArea.querySelector('h5');
        
        if (type === 'convert_word') {
            title.innerHTML = '<i class="fas fa-file-word me-2"></i>Convert to Word';
        } else if (type === 'convert_excel') {
            title.innerHTML = '<i class="fas fa-file-excel me-2"></i>Convert to Excel';
        }
    }

    showLoading(message) {
        // Show loading indicator
        const loadingToast = `
            <div class="toast align-items-center text-white bg-primary border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">
                        <div class="spinner-border spinner-border-sm me-2" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        ${message}
                    </div>
                </div>
            </div>
        `;
        this.showToast(loadingToast);
    }

    hideLoading() {
        // Hide loading indicator
        const loadingToasts = document.querySelectorAll('.toast.bg-primary');
        loadingToasts.forEach(toast => {
            const bsToast = bootstrap.Toast.getInstance(toast);
            if (bsToast) bsToast.hide();
        });
    }

    showSuccess(message) {
        const successToast = `
            <div class="toast align-items-center text-white bg-success border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">
                        <i class="fas fa-check-circle me-2"></i>
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;
        this.showToast(successToast);
    }

    showError(message) {
        const errorToast = `
            <div class="toast align-items-center text-white bg-danger border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;
        this.showToast(errorToast);
    }

    showToast(toastHTML) {
        let toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            toastContainer.style.zIndex = '1055';
            document.body.appendChild(toastContainer);
        }

        const toastElement = document.createElement('div');
        toastElement.innerHTML = toastHTML;
        const toast = toastElement.firstElementChild;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        // Remove toast element after it's hidden
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    }
}

// Global functions
function initializeDragAndDrop() {
    if (window.pdfApp) {
        window.pdfApp.initializeDragAndDrop();
    }
}

function startProcessing(jobType) {
    if (window.pdfApp) {
        window.pdfApp.startProcessing(jobType);
    }
}

function clearFiles(jobType) {
    if (window.pdfApp) {
        window.pdfApp.clearFiles(jobType);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.pdfApp = new PDFToolsApp();
});
