// Queue Management JavaScript
class QueueManager {
    constructor() {
        this.updateInterval = null;
        this.isUpdating = false;
        this.init();
    }

    init() {
        this.startStatusUpdates();
    }

    startStatusUpdates() {
        // Initial update
        this.updateQueueStatus();
        
        // Start periodic updates
        this.updateInterval = setInterval(() => {
            this.updateQueueStatus();
        }, 3000); // Update every 3 seconds
    }

    stopStatusUpdates() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
        }
    }

    async updateQueueStatus() {
        if (this.isUpdating) return;
        
        this.isUpdating = true;
        
        try {
            const response = await fetch('/api/queue/status');
            if (!response.ok) {
                throw new Error('Failed to fetch queue status');
            }

            const status = await response.json();
            this.displayQueueStatus(status);
            
        } catch (error) {
            console.error('Error updating queue status:', error);
            this.displayQueueError();
        } finally {
            this.isUpdating = false;
        }
    }

    displayQueueStatus(status) {
        const queueStatusElement = document.getElementById('queue-status');
        if (!queueStatusElement) return;

        const isActive = status.is_running && status.worker_count > 0;
        const queueSize = status.queue_size || 0;
        const userJobs = status.user_jobs || [];
        
        // Update main queue status
        queueStatusElement.innerHTML = `
            <div class="queue-info">
                <div class="queue-stat">
                    <i class="fas fa-server"></i>
                    <span>Queue Status: 
                        <span class="badge bg-${isActive ? 'success' : 'secondary'}">
                            ${isActive ? 'Active' : 'Inactive'}
                        </span>
                    </span>
                </div>
                <div class="queue-stat">
                    <i class="fas fa-tasks"></i>
                    <span>Jobs in Queue: <strong>${queueSize}</strong></span>
                </div>
                <div class="queue-stat">
                    <i class="fas fa-users"></i>
                    <span>Your Active Jobs: <strong>${userJobs.length}</strong></span>
                </div>
            </div>
        `;

        // Update user jobs display
        this.displayUserJobs(userJobs);
    }

    displayUserJobs(jobs) {
        const processingJobsElement = document.getElementById('processing-jobs');
        if (!processingJobsElement) return;

        if (jobs.length === 0) {
            processingJobsElement.innerHTML = `
                <div class="text-center text-muted py-3">
                    <i class="fas fa-clipboard-check mb-2" style="font-size: 2rem;"></i>
                    <p>No active processing jobs</p>
                </div>
            `;
            return;
        }

        processingJobsElement.innerHTML = '';
        
        jobs.forEach(job => {
            const jobElement = document.createElement('div');
            jobElement.className = 'job-item fade-in';
            jobElement.innerHTML = this.getJobHTML(job);
            processingJobsElement.appendChild(jobElement);
        });
    }

    getJobHTML(job) {
        const statusClass = `status-${job.status}`;
        const progressPercent = job.progress || 0;
        const jobTypeDisplay = job.job_type.replace('_', ' ').toUpperCase();
        
        return `
            <div class="job-header">
                <h6 class="job-title">
                    <i class="fas fa-${this.getJobTypeIcon(job.job_type)} me-2"></i>
                    ${jobTypeDisplay}
                </h6>
                <div class="job-status">
                    <span class="status-badge ${statusClass}">${job.status.toUpperCase()}</span>
                    ${job.status === 'completed' ? `
                        <a href="/download/${job.id}" class="btn btn-sm btn-success ms-2" title="Download Results">
                            <i class="fas fa-download"></i>
                        </a>
                    ` : ''}
                    ${job.status === 'pending' ? `
                        <button class="btn btn-sm btn-outline-danger ms-2" 
                                onclick="queueManager.cancelJob('${job.id}')"
                                title="Cancel Job">
                            <i class="fas fa-times"></i>
                        </button>
                    ` : ''}
                </div>
            </div>
            <div class="progress mb-2">
                <div class="progress-bar ${job.status === 'processing' ? 'progress-bar-striped progress-bar-animated' : ''}" 
                     role="progressbar" 
                     style="width: ${progressPercent}%"
                     aria-valuenow="${progressPercent}" 
                     aria-valuemin="0" 
                     aria-valuemax="100">
                    ${progressPercent > 0 ? `${progressPercent}%` : ''}
                </div>
            </div>
            <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">
                    <i class="fas fa-clock me-1"></i>
                    ${this.formatDateTime(job.created_at)}
                </small>
                <small class="text-muted">
                    ID: ${job.id.substring(0, 8)}...
                </small>
            </div>
        `;
    }

    getJobTypeIcon(jobType) {
        const icons = {
            'merge': 'object-group',
            'split': 'cut',
            'compress': 'compress',
            'ocr': 'eye',
            'convert_word': 'file-word',
            'convert_excel': 'file-excel'
        };
        return icons[jobType] || 'file-pdf';
    }

    formatDateTime(isoString) {
        const date = new Date(isoString);
        return date.toLocaleString();
    }

    async cancelJob(jobId) {
        if (!confirm('Are you sure you want to cancel this job?')) {
            return;
        }

        try {
            const response = await fetch(`/job/${jobId}/cancel`, {
                method: 'POST'
            });

            if (!response.ok) {
                throw new Error('Failed to cancel job');
            }

            const result = await response.json();
            
            if (result.error) {
                throw new Error(result.error);
            }

            this.showSuccess('Job cancelled successfully');
            
            // Force immediate update
            setTimeout(() => {
                this.updateQueueStatus();
            }, 500);
            
        } catch (error) {
            this.showError(`Failed to cancel job: ${error.message}`);
        }
    }

    displayQueueError() {
        const queueStatusElement = document.getElementById('queue-status');
        if (!queueStatusElement) return;

        queueStatusElement.innerHTML = `
            <div class="alert alert-warning mb-0">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Unable to connect to queue service. Please refresh the page.
            </div>
        `;
    }

    showSuccess(message) {
        this.showToast(message, 'success');
    }

    showError(message) {
        this.showToast(message, 'danger');
    }

    showToast(message, type = 'info') {
        let toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            toastContainer.style.zIndex = '1055';
            document.body.appendChild(toastContainer);
        }

        const toastHTML = `
            <div class="toast align-items-center text-white bg-${type} border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">
                        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;

        const toastElement = document.createElement('div');
        toastElement.innerHTML = toastHTML;
        const toast = toastElement.firstElementChild;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        // Remove toast element after it's hidden
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    }

    // Cleanup method
    destroy() {
        this.stopStatusUpdates();
    }
}

// Global functions for queue management
function startQueueStatusUpdates() {
    if (window.queueManager) {
        window.queueManager.startStatusUpdates();
    }
}

function stopQueueStatusUpdates() {
    if (window.queueManager) {
        window.queueManager.stopStatusUpdates();
    }
}

// Initialize queue manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.queueManager = new QueueManager();
});

// Cleanup when page is about to be unloaded
window.addEventListener('beforeunload', function() {
    if (window.queueManager) {
        window.queueManager.destroy();
    }
});

// Handle visibility changes (pause updates when tab is not active)
document.addEventListener('visibilitychange', function() {
    if (window.queueManager) {
        if (document.hidden) {
            window.queueManager.stopStatusUpdates();
        } else {
            window.queueManager.startStatusUpdates();
        }
    }
});
